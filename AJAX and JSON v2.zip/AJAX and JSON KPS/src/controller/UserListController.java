package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import model.User;
import model.UserDAO;

/**
 * Servlet implementation class StudentListController
 */
@WebServlet("/list")
public class UserListController extends HttpServlet {

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(request.getRequestURL());
		try {
			ArrayList<User> arr = new UserDAO().getUserList();
			response.setContentType("application/json");
			JSONArray json = new JSONArray(arr);
			response.getWriter().write(json.toString());
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}


}







