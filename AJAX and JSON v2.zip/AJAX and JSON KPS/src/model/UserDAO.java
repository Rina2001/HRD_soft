package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class UserDAO {
	
	public ArrayList<User> getUserList() throws ClassNotFoundException, SQLException{
		Statement st = ConnectionManager.getConnection().createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM tbuser");
		ArrayList<User> arr = new ArrayList<>();
		while(rs.next())
			arr.add(new User(rs.getString("username"), rs.getString("password")));
		return arr;
	}
	
	public boolean insertUser(User u) throws ClassNotFoundException, SQLException{
		String sql = "INSERT INTO tbuser values(?, ?)";
		PreparedStatement ps = ConnectionManager.getConnection().prepareStatement(sql);
		ps.setString(1, u.getUsername());
		ps.setString(2, u.getPassword());
		if(ps.executeUpdate()>0)
			return true;
		return false;
	}
	
}
